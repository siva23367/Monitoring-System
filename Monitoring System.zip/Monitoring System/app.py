from flask import Flask, jsonify
import requests
from datetime import datetime

app = Flask(__name__)

API_KEY = 'YOUR_API_KEY'  # Replace with your OpenWeatherMap API key
CITY = 'Mumbai'  # Replace with desired city name

# Endpoint to fetch real-time weather data
@app.route('/weather', methods=['GET'])
def get_weather():
    url = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather_data = {
            "temperature": data['main']['temp'],
            "humidity": data['main']['humidity'],
            "pressure": data['main']['pressure'],
            "description": data['weather'][0]['description'],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        return jsonify(weather_data)
    else:
        return jsonify({"error": "Failed to fetch data from the API"}), response.status_code

if __name__ == '__main__':
    app.run(debug=True)

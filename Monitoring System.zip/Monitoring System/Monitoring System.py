import requests
import streamlit as st
import plotly.graph_objects as go
from datetime import datetime
import time

# OpenWeatherMap API Key and City Configuration
API_KEY = 'YOUR_API_KEY'
CITY = 'Mumbai'  # Change this to your desired city

# Function to fetch weather data
def fetch_weather_data():
    url = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather_data = {
            "temperature": data['main']['temp'],
            "humidity": data['main']['humidity'],
            "pressure": data['main']['pressure'],
            "description": data['weather'][0]['description'],
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        return weather_data
    else:
        st.error("Failed to fetch data from the API")
        return None

# Streamlit Dashboard Setup
st.title("Real-Time Weather Monitoring System")
st.write(f"Weather data for {CITY}")

# Initialize empty lists to store data
timestamps = []
temperatures = []
humidities = []
pressures = []

# Real-time Data Loop
while True:
    weather_data = fetch_weather_data()
    if weather_data:
        # Update data lists
        timestamps.append(weather_data["timestamp"])
        temperatures.append(weather_data["temperature"])
        humidities.append(weather_data["humidity"])
        pressures.append(weather_data["pressure"])

        # Clear existing Streamlit elements and display updated data
        st.empty()
        st.subheader("Latest Weather Data")
        st.write(f"Temperature: {weather_data['temperature']}°C")
        st.write(f"Humidity: {weather_data['humidity']}%")
        st.write(f"Pressure: {weather_data['pressure']} hPa")
        st.write(f"Condition: {weather_data['description']}")
        st.write(f"Timestamp: {weather_data['timestamp']}")

        # Plot real-time data with Plotly
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=timestamps, y=temperatures, mode='lines+markers', name='Temperature (°C)'))
        fig.add_trace(go.Scatter(x=timestamps, y=humidities, mode='lines+markers', name='Humidity (%)'))
        fig.add_trace(go.Scatter(x=timestamps, y=pressures, mode='lines+markers', name='Pressure (hPa)'))
        
        # Update layout
        fig.update_layout(title="Real-Time Weather Data Trends",
                          xaxis_title="Timestamp",
                          yaxis_title="Values",
                          xaxis=dict(type='category'))

        st.plotly_chart(fig)

    # Pause for a minute before fetching new data
    time.sleep(60)  # Fetch new data every minute

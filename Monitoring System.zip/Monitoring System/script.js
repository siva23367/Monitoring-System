const temperatureEl = document.getElementById('temperature');
const humidityEl = document.getElementById('humidity');
const pressureEl = document.getElementById('pressure');
const descriptionEl = document.getElementById('description');
const timestampEl = document.getElementById('timestamp');

let temperatureData = [];
let humidityData = [];
let pressureData = [];
let timeLabels = [];

function fetchWeatherData() {
    fetch('http://127.0.0.1:5000/weather')
        .then(response => response.json())
        .then(data => {
            // Update UI elements
            temperatureEl.innerText = data.temperature;
            humidityEl.innerText = data.humidity;
            pressureEl.innerText = data.pressure;
            descriptionEl.innerText = data.description;
            timestampEl.innerText = data.timestamp;

            // Update chart data
            temperatureData.push(data.temperature);
            humidityData.push(data.humidity);
            pressureData.push(data.pressure);
            timeLabels.push(data.timestamp);

            // Limit data to the last 10 entries
            if (temperatureData.length > 10) {
                temperatureData.shift();
                humidityData.shift();
                pressureData.shift();
                timeLabels.shift();
            }

            updateChart();
        })
        .catch(error => console.error('Error fetching weather data:', error));
}

function updateChart() {
    weatherChart.data.labels = timeLabels;
    weatherChart.data.datasets[0].data = temperatureData;
    weatherChart.data.datasets[1].data = humidityData;
    weatherChart.data.datasets[2].data = pressureData;
    weatherChart.update();
}

const ctx = document.getElementById('weatherChart').getContext('2d');
const weatherChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: timeLabels,
        datasets: [
            {
                label: 'Temperature (°C)',
                data: temperatureData,
                borderColor: 'red',
                fill: false,
            },
            {
                label: 'Humidity (%)',
                data: humidityData,
                borderColor: 'blue',
                fill: false,
            },
            {
                label: 'Pressure (hPa)',
                data: pressureData,
                borderColor: 'green',
                fill: false,
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            x: { title: { display: true, text: 'Time' } },
            y: { title: { display: true, text: 'Value' } }
        }
    }
});

// Fetch data every minute
setInterval(fetchWeatherData, 60000); // 60 seconds
fetchWeatherData(); // Initial fetch
